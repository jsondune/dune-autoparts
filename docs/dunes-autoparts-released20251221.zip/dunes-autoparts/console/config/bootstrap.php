<?php
Yii::setAlias('@consoleRoot', dirname(__DIR__));
