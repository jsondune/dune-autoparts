<?php
Yii::setAlias('@apiWeb', '/api/web');
