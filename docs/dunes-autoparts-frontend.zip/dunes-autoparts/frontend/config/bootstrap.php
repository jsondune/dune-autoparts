<?php
Yii::setAlias('@frontend', dirname(__DIR__));
