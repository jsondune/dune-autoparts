<?php
return [
    'shopName' => "Dune's Auto Parts",
    'shopSlogan' => 'อะไหล่รถยนต์คุณภาพ ราคาโรงงาน',
    'shopPhone' => '02-xxx-xxxx',
    'shopEmail' => 'info@dunesautoparts.com',
    'shopAddress' => '123 ถนนพระราม 4 แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110',
    'shopLine' => '@dunesautoparts',
    'shopFacebook' => 'dunesautoparts',
    'freeShippingMinimum' => 2000,
    'itemsPerPage' => 12,
];
