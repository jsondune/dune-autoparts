<?php
Yii::setAlias('@backendWeb', '/backend/web');
